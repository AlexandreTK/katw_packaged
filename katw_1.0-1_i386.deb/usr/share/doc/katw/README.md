Kays Against The World is a game developed in C++. Brought to you by Sandstorm Games.
