#ifndef _DEFINES_H_
#define _DEFINES_H_


#define TILE_SIZE 32

#endif
