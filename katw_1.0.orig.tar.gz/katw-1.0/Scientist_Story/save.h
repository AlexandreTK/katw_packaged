#pragma once


class Save{
    public:

    static void saveGame();
    static void loadGame();

};
