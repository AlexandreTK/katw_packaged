#include "GameObjectFactory.h"

//initializer
GameObjectFactory * GameObjectFactory::instance = NULL;

//Destructor
GameObjectFactory::~GameObjectFactory()
{

}
